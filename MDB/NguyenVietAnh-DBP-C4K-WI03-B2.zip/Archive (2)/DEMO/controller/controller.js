import {initHtml} from './menu.js';
import {initProducts} from './db.js'

window.onload = () => {
    initHtml()
}

