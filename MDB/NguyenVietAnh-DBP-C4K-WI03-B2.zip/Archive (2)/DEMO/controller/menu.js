import { initProducts } from "./db.js";
// Bước 1: Khởi tạo các thành phần
var shop_menu = document.createElement('div');
var shop_content = document.createElement('div');
let initHtml = function() {
  shop_menu.id = 'shop_menu';
  document.body.appendChild(shop_menu);

  shop_content.id = 'shop_content';
  document.body.appendChild(shop_content);

  getMenu()
  loadHome()
  //getHello()
  //getProduct()
  //loadCard()
}

let getMenu = async function() {
  let response = await fetch("./views/menu.html");
  let result = await response.text()
  document.getElementById("shop_menu").innerHTML = result;

  document.getElementById("btnHome").addEventListener('click', () => {
    console.log("Home");
    loadHome();
    initProducts()
  })

  document.getElementById("btnCategory").addEventListener('click', () => {
    console.log("Category");
    loadCategory();
  })

  document.getElementById("btnSupport").addEventListener('click', () => {
    console.log("HoTro");
    loadSupport()
  })
}

let getHello = async function() {
  let response = await fetch("./views/hello.html");
  let result = await response.text()
  shop_content.innerHTML = result;
}

let getProduct = async function() {
  let response = await fetch("./views/product.html");
  let result = await response.text()
  shop_content.innerHTML = result;
}

let loadHome = async function() {
  let response = await fetch("./views/home.html")
  let result = await response.text()
  shop_content.innerHTML = result;
}

let loadCategory = async function() {
  let response = await fetch("./views/category.html")
  let result = await response.text()
  shop_content.innerHTML = result;
}

let loadSupport = async function() {
    let response = await fetch("./views/support.html")
    let result = await response.text()
    shop_content.innerHTML = result;
}

let loadCard = async function() {
  let response =  await fetch("./views/card.html")
  let result = await response.text()
  return result
}

let renderCard = async function(card) {
  document.getElementById("lstCard").innerHTML += card
}

export {initHtml, getMenu, getHello, getProduct, loadCard, renderCard};