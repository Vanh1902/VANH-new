import { Product } from "./product.js";

export class Jewelry extends Product {
    constructor(name, price, image) {
        super(name, price, image)
    }
    ToPrice() {
        return super.ToPrice() * (95/100)
    }
} 