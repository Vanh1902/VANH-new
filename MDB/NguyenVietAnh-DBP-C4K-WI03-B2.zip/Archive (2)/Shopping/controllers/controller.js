import {initHtml} from './menu.js';

window.onload = () => {
    initHtml()
}

